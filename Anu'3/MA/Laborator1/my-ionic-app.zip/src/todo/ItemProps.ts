export interface ItemProps {
  id?: string;
  text: string;
}
